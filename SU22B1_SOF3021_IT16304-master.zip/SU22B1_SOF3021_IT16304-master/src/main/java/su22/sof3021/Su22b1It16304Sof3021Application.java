package su22.sof3021;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Su22b1It16304Sof3021Application {

	public static void main(String[] args) {
		SpringApplication.run(Su22b1It16304Sof3021Application.class, args);
	}

}
