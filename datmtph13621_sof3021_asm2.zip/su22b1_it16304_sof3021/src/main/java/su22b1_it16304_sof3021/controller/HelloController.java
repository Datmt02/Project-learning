package su22b1_it16304_sof3021.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class HelloController {
	@GetMapping("index")
	private String index() {
		return "index";
	}
	@GetMapping("account")
	public String callAccount(
			Model model
	) {
		String a = "accounts";
		model.addAttribute("path", a);
		return "redirect:/admin/accounts/index";
	}
}
