package su22b1_it16304_sof3021.controllers.admin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Formatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import su22b1_it16304_sof3021.beans.ProductModel;
import su22b1_it16304_sof3021.entities.Category;
import su22b1_it16304_sof3021.entities.Product;
import su22b1_it16304_sof3021.repositories.CategoryRepository;
import su22b1_it16304_sof3021.repositories.ProductRepository;

@Controller
@RequestMapping("/admin/products")
public class ProductController {
	@Autowired 
	public ProductRepository repository;
	
	@Autowired
	public CategoryRepository cateRepo;
	
	@PostMapping("store")
	public String store(
			ProductModel model,
			Product product
	) {
		product.setCategory(model.getCategory());
		product.setAvailable(model.getAvailable());
		product.setName(model.getName());
		product.setImage(model.getImage());
		product.setPrice(model.getPrice());
		product.setCreatedDate(model.getCreatedDate());
		
		repository.save(product);
		return "redirect:/admin/products/index";
	}
	
	@PostMapping("update/{id}")
	public String update(
			ProductModel model,
			@PathVariable("id") Product product
	) {
		product.setCategory(model.getCategory());
		product.setAvailable(model.getAvailable());
		product.setName(model.getName());
		product.setImage(model.getImage());
		product.setPrice(model.getPrice());
		product.setCreatedDate(model.getCreatedDate());
		
		repository.save(product);
		return "redirect:/admin/products/index";
	}
	
	@GetMapping("delete/{id}")
	public String delete(@PathVariable("id") Integer id) {
		
		repository.deleteById(id);
		return "redirect:/admin/products/index";
	}
	
	@GetMapping("edit/{id}")
	public String edit(
			@PathVariable("id") Product item,
			Model model
	) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		Pageable pageable = PageRequest.of(0, 5);
		Page<Product> data = this.repository.findAll(pageable);
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		List<Category> calst = this.cateRepo.findAll();
		model.addAttribute("calst", calst);
		
		Date oldDate = item.getCreatedDate();
		String newDate = format.format(oldDate);
		model.addAttribute("newDate", newDate);
		
		return "admin/products/index";
	}
	@GetMapping("index")
	public String index(
		Model model,
		Product item
	) {
//		model.addAttribute("a", "admin/products/_form.jsp");
//		model.addAttribute("b", "admin/products/_formUpdate.jsp");
//		model.addAttribute("c", "admin/products/_table.jsp");
		
		Pageable pageable = PageRequest.of(0, 5, Sort.by("id"));
		Page<Product> data = this.repository.findAll(pageable);
		
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		List<Category> calst = this.cateRepo.findAll();
		model.addAttribute("calst", calst);
		
		return "admin/products/index";
	}
}
