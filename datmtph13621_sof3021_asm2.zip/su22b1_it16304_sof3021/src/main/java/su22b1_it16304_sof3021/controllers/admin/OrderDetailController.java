package su22b1_it16304_sof3021.controllers.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import su22b1_it16304_sof3021.beans.OrderDetailModel;
import su22b1_it16304_sof3021.entities.Category;
import su22b1_it16304_sof3021.entities.Order;
import su22b1_it16304_sof3021.entities.OrderDetail;
import su22b1_it16304_sof3021.entities.Product;
import su22b1_it16304_sof3021.repositories.OrderDetailRepository;
import su22b1_it16304_sof3021.repositories.OrderRepository;
import su22b1_it16304_sof3021.repositories.ProductRepository;

@Controller
@RequestMapping("/admin/orderDetails")
public class OrderDetailController {
	@Autowired
	private OrderDetailRepository detailRepo;
	
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private ProductRepository productRepo;
	
	@PostMapping("store")
	public String store(OrderDetailModel detailModel, OrderDetail detail)
	{
		detail.setOrder(detailModel.getOrder());
		detail.setProduct(detailModel.getProduct());
		detail.setPrice(detailModel.getPrice());
		detail.setQuantity(detailModel.getQuantity());
		
		detailRepo.save(detail);
		return "redirect:/admin/orderDetails/index";
	}
	@PostMapping("update/{id}")
	public String update(
			OrderDetailModel detailModel, 
			@PathVariable("id") OrderDetail detail)
	{
		detail.setOrder(detailModel.getOrder());
		detail.setProduct(detailModel.getProduct());
		detail.setPrice(detailModel.getPrice());
		detail.setQuantity(detailModel.getQuantity());
		
		detailRepo.save(detail);
		return "redirect:/admin/orderDetails/index";
	}
	@GetMapping("delete/{id}")
	public String delete(@PathVariable("id") Integer id) {
		
		detailRepo.deleteById(id);
		
		return "redirect:/admin/orderDetails/index";
	}
	@GetMapping("edit/{id}")
	public String edit(
			@PathVariable("id") Integer id,
			Model model
	) {
		OrderDetail item =  this.detailRepo.getById(id);
		Pageable pageable = PageRequest.of(0, 5);
		Page<OrderDetail> data = this.detailRepo.findAll(pageable);
		
		List<Order> orderList = this.orderRepo.findAll();
		List<Product> productList = this.productRepo.findAll();
		
		model.addAttribute("orderList", orderList);
		model.addAttribute("productList", productList);
		
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		return "admin/orderDetails/index";
	}
	
	@GetMapping("index")
	public String index(
			Model model,
			OrderDetail item
	) {
		Pageable pageable = PageRequest.of(0, 5, Sort.by("id"));
		Page<OrderDetail> data = this.detailRepo.findAll(pageable);
		
		List<Order> orderList = this.orderRepo.findAll();
		List<Product> productList = this.productRepo.findAll();
		
		model.addAttribute("orderList", orderList);
		model.addAttribute("productList", productList);
		
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		return"admin/orderDetails/index";
	}
}
