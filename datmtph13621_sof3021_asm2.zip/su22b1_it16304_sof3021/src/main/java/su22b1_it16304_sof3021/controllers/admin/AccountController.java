package su22b1_it16304_sof3021.controllers.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import su22b1_it16304_sof3021.beans.AccountModel;
import su22b1_it16304_sof3021.entities.Account;
import su22b1_it16304_sof3021.repositories.AccountRepository;

@Controller
@RequestMapping("/admin/accounts")
public class AccountController {
	@Autowired
	private AccountRepository accountRepo;
	
	@PostMapping("store")
	public String store(AccountModel accModel,Account account)
	{
		// Chuyển AccountModel -> entities.Account
		 
		account.setFullname(accModel.getFullname());
		account.setEmail(accModel.getEmail());
		account.setUsername(accModel.getUsername());
		account.setPassword(accModel.getPassword());
		account.setPhoto(accModel.getPhoto());
		account.setAdmin(accModel.getAdmin());
		account.setActivated(0);
		this.accountRepo.save(account);

		return "redirect:/admin/accounts/index";
	}
	
	@GetMapping("delete/{id}")
	public String delete(@PathVariable("id") Integer id)
	{
		// Truy vấn theo id
		accountRepo.deleteById(id);
		
		return "redirect:/admin/accounts/index";
	}
	@PostMapping("update/{id}")
	public String update(@PathVariable("id") Account account, 
			AccountModel accModel)
	{
		
		account.setFullname(accModel.getFullname());
		account.setEmail(accModel.getEmail());
		account.setUsername(accModel.getUsername());
		account.setPassword(accModel.getPassword());
		account.setPhoto(accModel.getPhoto());
		account.setAdmin(accModel.getAdmin());
		account.setActivated(0);
		this.accountRepo.save(account);
		
		return "redirect:/admin/accounts/index";
	}
	@GetMapping("edit/{id}")
	public String edit(
			Model model,
			@PathVariable("id") Integer id
	) {
		
		Account item = this.accountRepo.findById(id).get();
		Pageable pageable = PageRequest.of(0, 5);
		Page<Account> data = this.accountRepo.findAll(pageable);
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		return "admin/accounts/index";
	}
	
	@GetMapping("index")
	public String index(
			Model model,
			Account item
	) {
		
		Pageable pageable = PageRequest.of(0, 5, Sort.by("id"));
		Page<Account> data = this.accountRepo.findAll(pageable);
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		return "admin/accounts/index";
	}
}
