package su22b1_it16304_sof3021.beans;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import su22b1_it16304_sof3021.entities.Category;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductModel {

	private String name;
	private String image;
	private double price;
	private int available;
	private Category category;
	private Date createdDate;
}
