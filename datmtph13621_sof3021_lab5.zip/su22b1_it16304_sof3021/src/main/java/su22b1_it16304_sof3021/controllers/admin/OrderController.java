package su22b1_it16304_sof3021.controllers.admin;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import su22b1_it16304_sof3021.beans.OrderModel;
import su22b1_it16304_sof3021.entities.Account;
import su22b1_it16304_sof3021.entities.Order;
import su22b1_it16304_sof3021.repositories.AccountRepository;
import su22b1_it16304_sof3021.repositories.OrderRepository;

@Controller
@RequestMapping("/admin/orders")
public class OrderController {
	@Autowired
	private OrderRepository orderRepo;
	
	@Autowired
	private AccountRepository accountRepo;
	
	@PostMapping("store")
	public String store(
			OrderModel orderModel,
			Order order
	) {
		order.setUser(orderModel.getUser());
		order.setCreatedDate(orderModel.getCreatedDate());
		order.setAddress(orderModel.getAddress());
		
		orderRepo.save(order);
		return "redirect:/admin/orders/index";
	}
	
	@PostMapping("update/{id}")
	public String update(
			@PathVariable("id") Order order,
			OrderModel orderModel
	) {
		
		order.setUser(orderModel.getUser());
		order.setCreatedDate(orderModel.getCreatedDate());
		order.setAddress(orderModel.getAddress());
		
		orderRepo.save(order);
		return "redirect:/admin/orders/index";
	}
	
	@GetMapping("edit/{id}")
	public String edit(
			@PathVariable("id") Integer id,
			Model model
	) {
		Order item = this.orderRepo.getById(id);
		Pageable pageable = PageRequest.of(0, 5);
		Page<Order> data = this.orderRepo.findAll(pageable);
		
		List<Account> accList = this.accountRepo.findAll();
		model.addAttribute("accList", accList);
		
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date oldDate = item.getCreatedDate();
		String newDate = formatter.format(oldDate);
		
		model.addAttribute("newDate", newDate);
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		return "index";
	}
	@GetMapping("delete/{id}")
	public String delete(
			@PathVariable("id") Integer id
	) {
		orderRepo.deleteById(id);
		return "redirect:/admin/orders/index";
	}
	@GetMapping("index")
	public String index(
			Model model,
			Order item
	){
		Pageable pageable = PageRequest.of(0, 5);
		Page<Order> data = this.orderRepo.findAll(pageable);
		model.addAttribute("data", data);
		model.addAttribute("item", item);
		
		List<Account> accList = this.accountRepo.findAll();
		model.addAttribute("accList", accList);
		return "index";
	}
}
