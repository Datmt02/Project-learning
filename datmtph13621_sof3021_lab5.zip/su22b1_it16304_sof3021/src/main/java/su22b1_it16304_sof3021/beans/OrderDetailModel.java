package su22b1_it16304_sof3021.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import su22b1_it16304_sof3021.entities.Order;
import su22b1_it16304_sof3021.entities.Product;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDetailModel {
	private Order order;
	private Product product;
	private double price;
	private int quantity;
}
