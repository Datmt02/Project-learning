package su22b1_it16304_sof3021;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Su22b1It16304Sof3021ApplicationTests {

	@Test
	void contextLoads() {
	}

}
