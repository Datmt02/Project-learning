package com.example.demo.beans;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class User {
	@NotBlank(message="Không được để trống")
	private String hoTen;

	@NotBlank
	private String diaChi;

	@NotNull
	private int gioiTinh;

	@NotBlank
	@Email
	@Pattern(regexp="$(fpt.edu.vn)")
	private String email;

	@NotBlank
	private String password;
	
	@NotBlank
	private String sdt;
	
	private String avatar;
}
