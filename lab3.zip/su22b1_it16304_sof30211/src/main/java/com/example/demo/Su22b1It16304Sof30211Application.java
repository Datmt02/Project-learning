package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Su22b1It16304Sof30211Application {

	public static void main(String[] args) {
		SpringApplication.run(Su22b1It16304Sof30211Application.class, args);
	}

}
