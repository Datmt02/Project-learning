package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.demo.beans.*;
@Controller
public class loginController {
	@GetMapping("login")
	public String getLoginForm()
	{
		return "login";
	}
	
//	@PostMapping("login")
//	public String Login(
//		@RequestParam(name="email") String email,
//		@RequestParam(name="password") String password
//	){
//		System.out.println(email);
//		System.out.println(password);
//		return "login";
//	}
	@PostMapping("login")
	public String login(login login) {
		System.out.println(login.getEmail());
		System.out.println(login.getPassword());
		return "login";
	}
}
