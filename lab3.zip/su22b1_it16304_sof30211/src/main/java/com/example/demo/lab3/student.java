package com.example.demo.lab3;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

	public class student {
	@NotBlank(message="Vui Lòng nhập Họ Tên")
	 String name;
	
	@NotBlank(message="Vui Lòng nhập Địa Chỉ Email!")
	@Email(message = "Vui Lòng Nhập Đúng Định Dạng")
	 String email;

	@Min(0)
	@Max(10)
	@NotNull(message="Vui Lòng nhập điểm")
	 Double marks;
	@NotNull(message="Vui Lòng chọn giới tính")
	 Boolean gender;
	@NotBlank(message = "Vui Lòng chọn khoa")
	 String faculty;
	@NotEmpty(message = "Vui lòng chọn sở thích")
	 List<String> hobbies;
	
}
