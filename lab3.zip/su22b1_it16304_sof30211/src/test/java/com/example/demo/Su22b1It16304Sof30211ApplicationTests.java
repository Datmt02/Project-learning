package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Su22b1It16304Sof30211ApplicationTests {

	@Test
	void contextLoads() {
	}

}
